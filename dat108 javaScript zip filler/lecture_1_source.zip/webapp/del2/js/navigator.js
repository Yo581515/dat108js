"use strict";

/**
 * Koden er laget for å funger også i eldre nettlesere. Idag vil vi bruke mer
 * moderne strukterer, f.eks. "class" og opprette klasser, men da vil koden feile
 * i eldre nettlesere.
 */

{
   function show(value) {
        if (value == null) {
            return "undefined";
        } else {
           if (typeof value == "string") {
               if (value.trim() == "") {
                   return "<empty string>";
               } else {
                   return value;
               }
           } else {
               return value;
           }
        }
    }

//.toString().trim() == "") {

    function init() {
        document.getElementById("appCodeName").textContent = show(navigator.appCodeName);
        document.getElementById("appMinorVersion").textContent = show(navigator.appMinorVersion);
        document.getElementById("appName").textContent = show(navigator.appName);
        document.getElementById("appVersion").textContent = show(navigator.appVersion);
        document.getElementById("battery").textContent = show(navigator.battery);
        document.getElementById("browserLanguage").textContent = show(navigator.browserLanguage);
        document.getElementById("buildID").textContent = show(navigator.buildID);
        document.getElementById("cookieEnabled").textContent = show(navigator.cookieEnabled);
        document.getElementById("cpuClass").textContent = show(navigator.cpuClass);
        document.getElementById("connection").textContent = show(navigator.connection);
        document.getElementById("deviceMemory").textContent = show(navigator.deviceMemory);
        document.getElementById("doNotTrack").textContent = show(navigator.doNotTrack);
        document.getElementById("geolocation").textContent = show(navigator.geolocation);
        document.getElementById("credentials").textContent = show(navigator.credentials);
        document.getElementById("hardwareConcurrency").textContent = show(navigator.hardwareConcurrency);
        document.getElementById("javaEnabled").textContent = show(navigator.javaEnabled());
        document.getElementById("keyboard").textContent = show(navigator.keyboard);
        document.getElementById("languages").textContent = show(navigator.languages);
        document.getElementById("language").textContent = show(navigator.language);
        document.getElementById("locks").textContent = show(navigator.locks);
        document.getElementById("mediaCapabilities").textContent = show(navigator.mediaCapabilities);
        document.getElementById("mediaDevices").textContent = show(navigator.mediaDevices);
        document.getElementById("mimeTypes").textContent = show(navigator.mimeTypes);
        document.getElementById("onLine").textContent = show(navigator.onLine);
        document.getElementById("oscpu").textContent = show(navigator.oscpu);
        document.getElementById("permissions").textContent = show(navigator.permissions);
        document.getElementById("platform").textContent = show(navigator.platform);
        document.getElementById("plugins").textContent = show(navigator.plugins);
        document.getElementById("product").textContent = show(navigator.product);
        document.getElementById("productSub").textContent = show(navigator.productSub);
        document.getElementById("presentation").textContent = show(navigator.presentation);
        document.getElementById("serviceWorker").textContent = show(navigator.serviceWorker);
        document.getElementById("storageQuota").textContent = show(navigator.storageQuota);
        document.getElementById("storage").textContent = show(navigator.storage);
        document.getElementById("systemLanguage").textContent = show(navigator.systemLanguage);
        document.getElementById("userAgent").textContent = show(navigator.userAgent);
        document.getElementById("vendor").textContent = show(navigator.vendor);
        document.getElementById("vendorSub").textContent = show(navigator.vendorSub);
        document.getElementById("webdriver").textContent = show(navigator.webdriver);
        document.getElementById("webkitPointer").textContent = show(navigator.webkitPointer);
    }

    document.addEventListener('DOMContentLoaded',init);
}
