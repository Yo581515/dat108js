import DateManager from './components/datemanager/main.js';

customElements.define('date-manager', DateManager);
